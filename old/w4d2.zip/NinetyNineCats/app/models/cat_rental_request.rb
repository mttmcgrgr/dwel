class CatRentalRequest < ActiveRecord::Base
  validates :cat_id, :start_date, :end_date, presence: true
  validates :status, presence: true, inclusion: { in: %w(PENDING APPROVED DENIED) }
  validate :overlapping_approved_requests

  belongs_to :cat

  def overlapping_requests
    #requests have overlapping dates in scope cat_id

    CatRentalRequest
        .where(<<-SQL, self.id, cat_id, start_date, end_date, start_date, end_date)
        id != ? AND cat_id = ? AND ((start_date BETWEEN ? AND ?) OR (end_date BETWEEN ? AND ?))
        SQL
  end

  def full_overlap
    CatRentalRequest
        .where(<<-SQL, id, cat_id, start_date, end_date)
        id != ? AND cat_id = ? AND start_date < ? AND end_date > ?
        SQL
  end

  def overlapping_approved_requests
    if full_overlap.where(status: "APPROVED").count > 0 || overlapping_requests.where(status: 'APPROVED').count > 0
      errors[:request] << "conflicts with an approved request"
      false
    else
      true
    end
  end

  def approve!

    CatRentalRequest.transaction do
      self.overlapping_requests.each do |request|
        request.status = 'DENIED'
        request.save!
      end

     self.full_overlap.each do |request|
        request.status = 'DENIED'
        request.save!
      end

      self.status = 'APPROVED'
      self.save!
    end
  end

  def overlapping_pending_requests

  end

  def deny!
    self.status = 'DENIED'
    save
  end

  def pending?
    status == "PENDING"
  end

end
