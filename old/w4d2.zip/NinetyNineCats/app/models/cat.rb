require 'action_view'

class Cat < ActiveRecord::Base
  include ActionView::Helpers::DateHelper

  validates :birth_date, :name, :description, presence: true
  validates :color, presence: true, inclusion: { in: %w(black white brown orange sienna brindle),
    message: "%{value} is not a valid color" }
  validates :sex, presence: true, inclusion: { in: %w(M F),
    message: "Sex MUST be M or F" }

  has_many :requests,
    class_name: :CatRentalRequest,
    dependent: :destroy

  def age
    @age = time_ago_in_words(birth_date)
  end
end
