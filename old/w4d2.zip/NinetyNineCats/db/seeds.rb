# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)
cat1 = Cat.create({ birth_date: Date.new(2011,2,4), name: 'Kyle' , color: 'sienna', sex: 'F', description: 'Kyle is a coooool cat' })

cat2 = Cat.create({birth_date: Date.new(2002,2,28), name: 'Larry', color: 'black', sex: 'M', description: 'Larry shares Adrians birthday'})

cat3 = Cat.create(birth_date: Date.new(2016,11,23), name: 'Tiger', color: 'orange', sex: 'M', description: 'Tiger is a kitten!' )


request3 = CatRentalRequest.create({ cat_id: 1, start_date: Date.new(2016,12,12), end_date: Date.new(2017, 12, 9)})
request1 = CatRentalRequest.create({ cat_id: 1, start_date: Date.new(2016,12,7), end_date: Date.new(2016, 12, 9)})

request2 = CatRentalRequest.create({ cat_id: 2, start_date: 3.days.ago, end_date: 1.day.ago})
